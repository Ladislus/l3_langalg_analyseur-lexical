package SpecificationSyntaxique;

public class InvalidCharacterException extends Exception {

    public InvalidCharacterException(String msg) {
        super(msg);
    }
}
